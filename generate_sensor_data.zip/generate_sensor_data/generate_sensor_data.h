#ifndef GENERATE_SENSOR_DATA_H 
#define GENERATE_SENSOR_DATA_H

int generate_temperature_data(int num_regions, int num_records, const char *output_file);

#endif // GENERATE_SENSOR_DATA_H
