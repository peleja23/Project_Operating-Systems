1. Extract the sensor_data file, executing in the terminal the `tar` command below.

$ tar -xzvf sensor_data.bin.tar.gz

The final file's size should be aprox. 144 MB.

2. Run `make`
