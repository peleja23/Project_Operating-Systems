#include "sort.h"

int main(int argc, char* argv[]) {
    if (argc != 3) {
        printf("Uso: ./sort <ficheiro_dados> <região>\n");
        return 1;
    }

    const char* file_path = argv[1];
    int region_id = atoi(argv[2]);

    sort_region_data(file_path, region_id);

    return 0;
}
