#include "sort.h"

// Função para ler o cabeçalho
void read_header(int fd, int *num_regions, int *records_per_region) {
    lseek(fd, 0, SEEK_SET);
    read(fd, num_regions, sizeof(int));
    read(fd, records_per_region, sizeof(int));
}

// Função para ler e imprimir a região
void print_region(int fd, int region_id, int records_per_region) {
    int region_start = 8 + (region_id - 1) * records_per_region * sizeof(int);
    lseek(fd, region_start, SEEK_SET);

    int* records = (int*)malloc(records_per_region * sizeof(int));
    read(fd, records, records_per_region * sizeof(int));

    printf("Registos da região %d antes da ordenação:\n", region_id);
    for (int i = 0; i < records_per_region; i++) {
        printf("%d ", records[i]);
    }
    printf("\n");

    free(records);
}

// Função para ler e imprimir a região ordenada
void print_sorted_region(int fd, int region_id, int records_per_region) {
    int region_start = 8 + (region_id - 1) * records_per_region * sizeof(int);
    lseek(fd, region_start, SEEK_SET);

    int* records = (int*)malloc(records_per_region * sizeof(int));
    read(fd, records, records_per_region * sizeof(int));

    printf("Registos ordenados da região %d:\n", region_id);
    for (int i = 0; i < records_per_region; i++) {
        printf("%d ", records[i]);
    }
    printf("\n");

    free(records);
}

void insertion_sort(int* arr, int n) {
    for (int i = 1; i < n; i++) {
        int key = arr[i];
        int j = i - 1;

        // Mover os elementos maiores que o "key" para uma posição à frente
        while (j >= 0 && arr[j] > key) {
            arr[j + 1] = arr[j];
            j--;
        }
        arr[j + 1] = key;
    }
}

// Função principal de ordenação por região
void sort_region_data(const char* file_path, int region_id) {
    int fd = open(file_path, O_RDWR);

    int num_regions, records_per_region;
    read_header(fd, &num_regions, &records_per_region);

    print_region(fd, region_id, records_per_region);

    int region_start = 8 + (region_id - 1) * records_per_region * sizeof(int);
    int block_size = (int)records_per_region / 10;
    int num_blocks = (records_per_region + block_size - 1) / block_size;

    int *block = (int*)malloc(block_size * sizeof(int));

    // Ordenação dos blocos individualmente
    for (int i = 0; i < num_blocks; i++) {
        int start_pos = region_start + i * block_size * sizeof(int);
        lseek(fd, start_pos, SEEK_SET);

        int num_records_to_read = (i == num_blocks - 1) ? (records_per_region - i * block_size) : block_size;
        read(fd, block, num_records_to_read * sizeof(int));

        insertion_sort(block, num_records_to_read);

        lseek(fd, start_pos, SEEK_SET);
        write(fd, block, num_records_to_read * sizeof(int));
    }

    free(block);

    // MIstura dos blocos ordenados
    print_sorted_region(fd, region_id, records_per_region);

    close(fd);
}