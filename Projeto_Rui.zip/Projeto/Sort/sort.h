#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <string.h>

// Funções de manipulação de arquivos e ordenação
void sort_region_data(const char* file_path, int region_id);
void read_header(int fd, int *num_regions, int *records_per_region);
void print_region(int fd, int region_id, int records_per_region);
void print_sorted_region(int fd, int region_id, int records_per_region);
void merge_blocks(int fd, int region_start, int records_per_region, int block_size, int num_blocks);
void insertion_sort(int* arr, int n) ;


// Função para comparação de inteiros
int compare_ints(const void* a, const void* b);