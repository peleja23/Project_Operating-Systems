#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdint.h>
#include <sys/types.h>

// Definição da estrutura de estatísticas
typedef struct {
    int region_id;
    int median;
    float average;
    int max;
    int min;
} region_stats;

void read_statistics(const char *filename) {
    int fd = open(filename, O_RDONLY);
    if (fd < 0) {
        write(STDERR_FILENO, "Erro ao abrir o ficheiro de estatísticas\n", 42);
        exit(EXIT_FAILURE);
    }

    region_stats stats;
    ssize_t bytes_read = read(fd, &stats, sizeof(region_stats));
    if (bytes_read != sizeof(region_stats)) {
        write(STDERR_FILENO, "Erro ao ler as estatísticas do ficheiro\n", 41);
        close(fd);
        exit(EXIT_FAILURE);
    }
    close(fd);

    // Exibir os valores lidos
    write(STDOUT_FILENO, "Estatísticas da região:\n", 25);
    dprintf(STDOUT_FILENO, "ID da Região: %d\n", stats.region_id);
    dprintf(STDOUT_FILENO, "Mediana: %d\n", stats.median);
    dprintf(STDOUT_FILENO, "Média: %.2f\n", stats.average);
    dprintf(STDOUT_FILENO, "Valor Máximo: %d\n", stats.max);
    dprintf(STDOUT_FILENO, "Valor Mínimo: %d\n", stats.min);
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        write(STDERR_FILENO, "Uso: ./read_stats <ficheiro_estatisticas>\n", 42);
        return EXIT_FAILURE;
    }

    read_statistics(argv[1]);

    return EXIT_SUCCESS;
}
