#include "Stats.h"

int main(int argc, char *argv[]) {
    if (argc != 3) {
        display_usage();
        return EXIT_FAILURE;
    }

    const char *sensor_data_file = argv[1];
    int region_id = atoi(argv[2]);

    char output_file[50];
    construct_filename(output_file, region_id);

    if (run_sort_process(sensor_data_file, argv[2]) == EXIT_SUCCESS) {
        int *data = NULL;
        int records_per_region;

        if (load_region_data(sensor_data_file, region_id, &data, &records_per_region) == EXIT_SUCCESS) {
            save_statistics(output_file, region_id, data, records_per_region);
            free(data);
            display_success_message();
        }
    }

    return EXIT_SUCCESS;
}
