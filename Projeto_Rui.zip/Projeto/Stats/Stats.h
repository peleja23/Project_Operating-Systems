#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>

typedef struct {
    int region_id;
    int median;
    float average;
    int max;
    int min;
} region_stats;

// Declarações das funções
void display_usage();
void display_success_message();
int run_sort_process(const char *sensor_data_file, const char *region_id_str);
int load_region_data(const char *sensor_data_file, int region_id, int **data, int *records_per_region);
void save_statistics(const char *filename, int region_id, int *data, int count);
void construct_filename(char *buffer, int region_id);
int calculate_median(int *values, int count);
