#include "Stats.h"

// Exibe a mensagem de uso no console
void display_usage() {
    const char *usage = "Uso: ./stats <ficheiro_dados> <regiao>\n";
    write(STDERR_FILENO, usage, strlen(usage));
}

// Exibe a mensagem de sucesso no console
void display_success_message() {
    const char *success_msg = "Estatísticas salvas com sucesso\n";
    write(STDOUT_FILENO, success_msg, strlen(success_msg));
}

// Função para criar um processo para ordenar os dados usando sort
int run_sort_process(const char *sensor_data_file, const char *region_id_str) {
    pid_t pid = fork();
    if (pid == 0) {
        execlp("/home/rui-dias/Secretária/Projeto/Sort/sort", "sort", sensor_data_file, region_id_str, NULL);
        write(STDERR_FILENO, "Erro no exec do sort\n", 21);
        exit(EXIT_FAILURE);
    } else {
        int status;
        waitpid(pid, &status, 0);
        return (WIFEXITED(status) && WEXITSTATUS(status) == 0) ? EXIT_SUCCESS : EXIT_FAILURE;
    }
}

// Carrega os dados de uma região específica a partir do arquivo
int load_region_data(const char *sensor_data_file, int region_id, int **data, int *records_per_region) {
    int fd = open(sensor_data_file, O_RDONLY);
    if (fd == -1) return EXIT_FAILURE;

    int num_regions;
    read(fd, &num_regions, sizeof(int));
    read(fd, records_per_region, sizeof(int));

    *data = malloc(*records_per_region * sizeof(int));
    int offset = 2 * sizeof(int) + (region_id - 1) * (*records_per_region) * sizeof(int);
    lseek(fd, offset, SEEK_SET);
    read(fd, *data, (*records_per_region) * sizeof(int));

    close(fd);
    return EXIT_SUCCESS;
}

// Função para calcular a mediana
int calculate_median(int *values, int count) {
    if (count % 2 == 0)
        return (values[count / 2 - 1] + values[count / 2]) / 2;
    else
        return values[count / 2];
}

// Função para calcular as estatísticas e salvar no ficheiro binário
void save_statistics(const char *filename, int region_id, int *data, int count) {
    region_stats stats;
    stats.region_id = region_id;

    int sum = 0;
    stats.min = stats.max = data[0];
    for (int i = 0; i < count; i++) {
        sum += data[i];
        if (data[i] > stats.max) stats.max = data[i];
        if (data[i] < stats.min) stats.min = data[i];
    }
    stats.average = (float)sum / count;

    stats.median = calculate_median(data, count);

    int fd = open(filename, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    write(fd, &stats, sizeof(region_stats));
    close(fd);
}

// Função para construir o nome do ficheiro usando funções de baixo nível
void construct_filename(char *buffer, int region_id) {
    const char *prefix = "region-";
    int i;
    for (i = 0; prefix[i] != '\0'; i++) {
        buffer[i] = prefix[i];
    }

    buffer[i++] = '0' + (region_id / 100) % 10;
    buffer[i++] = '0' + (region_id / 10) % 10;
    buffer[i++] = '0' + region_id % 10;

    const char *suffix = "-stats.bin";
    for (int j = 0; suffix[j] != '\0'; j++, i++) {
        buffer[i] = suffix[j];
    }
    buffer[i] = '\0';
}
